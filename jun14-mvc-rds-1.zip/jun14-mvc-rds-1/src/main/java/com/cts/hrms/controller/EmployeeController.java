package com.cts.hrms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.hrms.entity.Employee;
import com.cts.hrms.service.EmployeeService;

@Controller
public class EmployeeController {
	@Autowired
	private EmployeeService es;
	
	@GetMapping("/")
	public String home(ModelMap model)
	{
		List<Employee> employees = es.read();
		model.addAttribute("employees", employees);
		model.addAttribute("employee", new Employee());
		return "employee";
	}

	@RequestMapping(method = RequestMethod.POST, value = "/employeeDml", params = "add")
	public String addEmployee(@ModelAttribute("employee")Employee employee, ModelMap model)
	{
		es.create(employee);
		return home(model);
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/employeeDml", params = "modify")
	public String modifyEmployee(@ModelAttribute("employee")Employee employee, ModelMap model)
	{
		es.update(employee);
		return home(model);
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/employeeDml", params = "remove")
	public String removeEmployee(@ModelAttribute("employee")Employee employee, ModelMap model)
	{
		es.delete(employee.getId());
		return home(model);
	}
	
	@GetMapping("/select")
	public String select(@RequestParam("id") Integer id, ModelMap model)
	{
		Employee employee = es.read(id);
		List<Employee> employees = es.read();
		model.addAttribute("employees", employees);
		model.addAttribute("employee", employee);
		return "employee";		
	}
}

package com.cts.hrms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jun14MvcRds1Application {

	public static void main(String[] args) {
		SpringApplication.run(Jun14MvcRds1Application.class, args);
	}

}
